#include <stdio.h>

int main() {
  printf("This is a test program\n");
  return 0;
}